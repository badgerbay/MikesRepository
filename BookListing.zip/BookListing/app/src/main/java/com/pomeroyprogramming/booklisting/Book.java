package com.pomeroyprogramming.booklisting;

/**
 * Created by Michael on 12/14/2017.
 */

/** MP The book class contains the general template for building a book object**/

import android.os.Parcel;
import android.os.Parcelable;

import java.util.Arrays;

/** MP Here we create a java object to hold all of the book information which will be displayed in each list item**/

public class Book implements Parcelable {

    /** MP Private variables are declared and initialized,
     * and then below public getter methods are used,
     * to allow other methods to access those private variables **/

    /** MPDeclare private variables for book information **/
    private String title;
    private String[] authors;

    /** MPInitialize a new book object with the new book data that is passed into this constructor**/
    public Book(String title, String[] authors) {
        this.title = title;
        this.authors = authors;
    }

    /** MPBecause the above book variables are private, we need public getter methods,
     * so that other classes can access this information **/

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String[] getAuthors() {
        return authors;
    }

    public void setAuthors(String[] authors) {
        this.authors = authors;
    }

    @Override
    public String toString() {
        return "Book{" +
                "title='" + title + '\'' +
                ", authors=" + Arrays.toString(authors) +
                '}';
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.title);
        dest.writeStringArray(this.authors);
    }

    protected Book(Parcel in) {
        this.title = in.readString();
        this.authors = in.createStringArray();
    }

    public static final Parcelable.Creator<Book> CREATOR = new Parcelable.Creator<Book>() {
        @Override
        public Book createFromParcel(Parcel source) {
            return new Book(source);
        }

        @Override
        public Book[] newArray(int size) {
            return new Book[size];
        }
    };
}

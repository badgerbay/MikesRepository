package com.pomeroyprogramming.booklisting;

import java.util.ArrayList;
import com.pomeroyprogramming.booklisting.Book;

/**
 * Created by Michael on 12/14/2017.
 */

public interface BookAsyncResponse {
    void processFinish(ArrayList<Book> bookArrayList);
}

package com.pomeroyprogramming.booklisting;

//  private final static String LOG_TAG = BookListingActivityFragment.class.getSimpleName();

//  Log.d(LOG_TAG, "onViewStateRestored");

import java.util.ArrayList;

public interface AsyncResponse {

    void processFinish(ArrayList<Book> bookArrayList);
}
